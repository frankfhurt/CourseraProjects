
public class CartaoBloqueadoException extends Exception {

	private static final long serialVersionUID = -1193034011142002534L;

	public CartaoBloqueadoException(String msg) {
		super(msg);
	}

}
