
public class UsuarioNaoLogadoException extends Exception {

	private static final long serialVersionUID = 1948416179195417558L;

	public UsuarioNaoLogadoException(String msgn) {
		super(msgn);
	}

}
