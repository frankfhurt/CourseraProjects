
public class DepositoComValorNegativoException extends Exception {

	private static final long serialVersionUID = 8444321519301288376L;

	public DepositoComValorNegativoException(String message) {
		super(message);
	}

}
