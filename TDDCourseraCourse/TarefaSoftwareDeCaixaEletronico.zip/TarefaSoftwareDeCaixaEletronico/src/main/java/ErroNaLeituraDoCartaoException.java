
public class ErroNaLeituraDoCartaoException extends Exception {

	private static final long serialVersionUID = 8070042303230494461L;

	public ErroNaLeituraDoCartaoException(String msgn) {
		super(msgn);
	}
}
