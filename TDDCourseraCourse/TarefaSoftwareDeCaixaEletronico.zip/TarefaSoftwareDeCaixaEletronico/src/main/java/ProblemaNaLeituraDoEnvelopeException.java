
public class ProblemaNaLeituraDoEnvelopeException extends Exception {

	private static final long serialVersionUID = 2516529837372097901L;

	public ProblemaNaLeituraDoEnvelopeException(String message) {
		super(message);
	}

}
