
public class EntregarDinheiroException extends Exception {

	private static final long serialVersionUID = 7089050670401552631L;

	public EntregarDinheiroException(String message) {
		super(message);
	}

}
