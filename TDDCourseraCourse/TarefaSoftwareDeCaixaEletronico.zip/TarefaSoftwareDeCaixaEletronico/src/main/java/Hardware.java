
public interface Hardware {

	public String pegarNumeroDaContaCartao(String nroConta) throws Exception;
	public void entregarDinheiro() throws Exception;
	public void lerEnvelope() throws Exception;
	
}
