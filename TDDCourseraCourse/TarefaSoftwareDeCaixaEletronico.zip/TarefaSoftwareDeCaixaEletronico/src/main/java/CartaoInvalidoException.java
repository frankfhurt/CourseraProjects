
public class CartaoInvalidoException extends Exception {

	private static final long serialVersionUID = -5455228000773593156L;

	public CartaoInvalidoException(String message) {
		super(message);
	}

}
